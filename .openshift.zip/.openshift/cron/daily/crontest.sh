date >> $OPENSHIFT_REPO_DIR/cron_test/date_daily.txt
php $OPENSHIFT_REPO_DIR/notify_email.php




